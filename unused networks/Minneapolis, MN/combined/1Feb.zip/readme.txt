This data feed no longer includes data for the Minnesota Valley Transit Authority (MVTA). MVTA data can downloaded here.  http://wiki.mvta.com/

6/1/2011
The stop_url field in stops.txt is now populated with the URL to open the stop in NexTrip.

1/17/2013
wheelchair_boarding field added to stops.txt. wheelchair_accessible added to trips.txt

2/12/2013
Updated MVTA link above.

5/30/2013
Added route_color and route_text_color to routes.txt for Metro Blue Line

5/19/2014
Updated metadata.
